


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Data {
        private static final Logger logger = Logger.getLogger(Data.class.getName());
        private static final String DB_DRIVER = "oracle.jdbc.driver.OracleDriver";
        
        
        private Data() {
                
        }
        
        public static Connection getDBConnection() throws SQLException {
                Connection connection = null;

                try {
                        Class.forName(DB_DRIVER);
                } catch (ClassNotFoundException exception) {
                        logger.log(Level.SEVERE, exception.getMessage());
                }

                try {
                	    connection = DriverManager.getConnection("jdbc:oracle:thin:@ 199.212.26.208:1521:SQLD","COMP214_M22_zo_23", "password"); 
                        return connection;
                } catch (SQLException exception) {
                        logger.log(Level.SEVERE, exception.getMessage());
                }

                return connection;
               
        }
        
        public static void closeConnection(Connection con) throws SQLException{
			if(con!=null){
				con.close();
				System.out.println("connection closed");
			}
		}	
}