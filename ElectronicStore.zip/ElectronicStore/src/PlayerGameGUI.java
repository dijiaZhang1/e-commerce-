




import java.awt.Frame;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
//import java.time.LocalDate;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;




public class PlayerGameGUI extends Application {

    
    public TextField playerIdField, firstNameField, lastNameField, addressField, postalCodeField, provinceField, phoneNumberField, gameIdField, gameTitleField, scoreField, datePlayedField,updateplayerid;
    public Button createPlayer,displayPlayer,updatePlayer;
    Statement st;

@Override
public void start(Stage primaryStage) {

	try {
		Connection con= Data.getDBConnection();
		//Create Border Pane Layout
		BorderPane border = new BorderPane();
		border.setLeft(addGridPaneLeft());
		border.setRight(addGridPaneRight());
		border.setBottom(addGridPanebottomRight());
	    Scene scene = new Scene(border, 900, 500);
	    // Place the scene in the stage
	    primaryStage.setScene(scene); 
	    //Display the stage
	    primaryStage.show();

		st=con.createStatement();	


		createPlayer.setOnAction(new EventHandler<ActionEvent>()
		{
			@Override
			public void handle(ActionEvent e)
			{
				int playerID = Integer.parseInt(playerIdField.getText());
				String firstName = firstNameField.getText();
                String lastName = lastNameField.getText();
                String address = addressField.getText();
                String province = provinceField.getText();
                String postalCode = postalCodeField.getText();
                String phoneNumber = phoneNumberField.getText();
                
                //Player player = new Player(firstName, lastName, address, postalCode, province, phoneNumber);
                //insertPlayerInfo(player);
                int gameID= Integer.parseInt(gameIdField.getText());
                String gameTitle = gameTitleField.getText();
                //Game game = new Game(gameTitle);
                //insertGameInfo(game);
                
                String playing_date = datePlayedField.getText().toString();
                int score = Integer.parseInt(scoreField.getText());
                int playergameID=concat(playerID,gameID);

              
                //LocalDate playedOn = playedDate.getValue();                                                    
                //PlayerAndGame playerGame = new PlayerAndGame(selectedGame.getGameId(), selectedPlayer.getPlayerId(), playedOn 
                //Integer.parseInt(score));
                //insertPlayerGameInfo(playerGame);
                

				try
				{
					Connection connection = Data.getDBConnection();
					String query = "INSERT INTO Player(PLAYERID,FIRSTNAME,LASTNAME,ADDRESS,PROVINCE,POSTALCODE,PHONENUMBER) VALUES (?, ?, ?, ?, ?, ?, ?)";
					PreparedStatement statement = connection.prepareStatement(query);
					//PreparedStatement statement = connection.prepareStatement(query,new String[]{"PLAYERID" });
					/*statement.setString(1, firstName);
                    statement.setString(2, lastName);
                    statement.setString(3, address );
                    statement.setString(4, postalCode);
                    statement.setString(5, province);
                    statement.setString(6, phoneNumber);*/
                    statement.setInt(1, playerID);
                    statement.setString(2, firstName);
                    statement.setString(3, lastName);
                    statement.setString(4, address );
                    statement.setString(6, postalCode);
                    statement.setString(5, province);
                    statement.setString(7, phoneNumber);
                    int count = statement.executeUpdate();
                    //if (count == 1) {
                    //        this.alert("Success", "Player Information inserted to DB successfully", AlertType.INFORMATION);
                    //} else {
                    //        this.alert("Failure", "Some error while adding Player Information", AlertType.ERROR);
                    //}
                    //statement.close();
                    String query2 = "INSERT INTO GAME(GAMEID,GAMETITLE) VALUES(?,?)";
                    PreparedStatement statement2 = connection.prepareStatement(query2);
                    //PreparedStatement statement2 = connection.prepareStatement(query,new String[]{"GAMEID" });
                    statement2.setInt(1, gameID);
					statement2.setString(2, gameTitle);
					int count2 = statement2.executeUpdate();
					//statement2.close();
					
					String query3 = "INSERT INTO PLAYERANDGAME(PLAYERGAMEID,GAMEID,PLAYERID,PLAYINGDATE,SCORE) VALUES(?,?,?,?,?)";
                    PreparedStatement statement3 = connection.prepareStatement(query3);
                 
                    statement3.setInt(1, playergameID);
					statement3.setInt(2, gameID);
					statement3.setInt(3, playerID);
					statement3.setString(4,playing_date);
					statement3.setInt(5, score);
					int count3 = statement3.executeUpdate();
					statement3.close();
			
				}
				catch (SQLException e1) {
				e1.printStackTrace();
				}
			}

			private void alert(String string, String string2, AlertType information) {
				// TODO Auto-generated method stub
				
			}
		});
		
		updatePlayer.setOnAction(new EventHandler<ActionEvent>()
		{
			@Override
			public void handle(ActionEvent e){   
				
				int updatebyid = Integer.parseInt(updateplayerid.getText());
				String address1 = addressField.getText();
				String postalCode1 = postalCodeField.getText();
				String province1 = provinceField.getText();
				String phoneNumber1 = phoneNumberField.getText();

				try
				{   
					//String updatePlayer = "UPDATE PLAYER SET ADDRESS='"+t_playerAddress.getText()+"' WHERE PLAYER_ID = "+t_updateplayerid.getText();
					//st.executeUpdate(updatePlayer);
					
					Connection connection = Data.getDBConnection();
					//String updatePlayer = "UPDATE PLAYER SET ADDRESS=IsNull(?, ADDRESS),PROVINCE=IsNull(?, PROVINCE),POSTALCODE=IsNull(?, POSTALCODE),PHONENUMBER=IsNull(?, PHONENUMBER), WHERE PLAYERID=?";
					String updatePlayer = "UPDATE PLAYER SET ADDRESS=?,PROVINCE=?,POSTALCODE=?,PHONENUMBER=? WHERE PLAYERID=?";
					PreparedStatement updateStatement = connection.prepareStatement(updatePlayer);
					
                    updateStatement.setString(1, address1 );
                    updateStatement.setString(2, province1);
                    updateStatement.setString(3, postalCode1);
                    updateStatement.setString(4, phoneNumber1);
                    updateStatement.setInt(5, updatebyid);
                    
                    /*
                    if  (addressField.getText() == null || addressField.getText().trim().isEmpty()) {
                    } 
                    else {updateStatement.setString(1, address1);}
                    
                    if  (provinceField.getText() == null || provinceField.getText().trim().isEmpty()) {
                    	
                    }
                    else {updateStatement.setString(2, province1);}
             
                    if  (postalCodeField.getText() == null || postalCodeField.getText().trim().isEmpty()) {
                    	
                    } 
                    else {updateStatement.setString(3, postalCode1);}
                    	
                    
                    if  (phoneNumberField.getText() == null || phoneNumberField.getText().trim().isEmpty()) {
                    }
                    else {updateStatement.setString(4, phoneNumber1);} */
                    
                    
                    
			        // call executeUpdate to execute updatePlayer
                    updateStatement.executeUpdate();
                    updateStatement.close();
			       
				}
				catch (SQLException e1) {
					e1.printStackTrace();
					}			
			}	
		});
		
		displayPlayer.setOnAction(new EventHandler<ActionEvent>()
		{
			@Override
			public void handle(ActionEvent e)
			{
				try
				{   Connection connection = Data.getDBConnection();
					st=connection.createStatement();
					DefaultTableModel model = new DefaultTableModel(new String[]{"Name", "ADDRESS","POSTALCODE","PHONENUMBER","GameTitle","Score","PlayingDate"}, 0);
					String selectPlayer = "select p.*,g.gameTitle,pg.score,pg.playingDate from player p join playerandgame pg on p.playerID = pg.playerID join game g on g.gameID = pg.gameID";

					ResultSet rs=st.executeQuery(selectPlayer);
					while(rs.next())
					{
						String name = rs.getString("FIRSTNAME") +  rs.getString("LASTNAME");
						String address = rs.getString("ADDRESS");
						String postalCode = rs.getString("POSTALCODE");
						String phoneNUmber = rs.getString("PHONENUMBER");
						String gameTitle = rs.getString("GAMETITLE");
						String score = rs.getString("SCORE");
						String playingdate = rs.getString("PLAYINGDATE");

						model.addRow(new Object[]{name,address,postalCode,phoneNUmber,gameTitle,score,playingdate});
						
						
						
					}
					Frame f=new Frame();
					JTable jt=new JTable(); 
					jt.setModel(model);
					jt.setBounds(30,40,200,300);          
					JScrollPane sp=new JScrollPane(jt);    
					f.add(sp);          
					f.setSize(300,400);    
					f.setVisible(true);  
			
					f.dispatchEvent(new WindowEvent(f, WindowEvent.WINDOW_CLOSING));
				}
				catch (Exception e1) {
					e1.printStackTrace();
					}			
			}	
		});
		

	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
}


//Java program to concatenate
//two integers into one

static int concat(int a, int b)
{

	// Convert both the integers to string
	String s1 = Integer.toString(a);
	String s2 = Integer.toString(b);

	// Concatenate both strings
	String s = s1 + s2;

	// Convert the concatenated string
	// to integer
	int c = Integer.parseInt(s);

	// return the formed integer
	return c;
}


public GridPane addGridPaneLeft()
{
	GridPane pane = new GridPane();
    pane.setAlignment(Pos.TOP_LEFT);
    pane.setPadding(new Insets(11, 12, 13, 14));
    pane.setHgap(10);
    pane.setVgap(5);
	//Adding Text fields
    playerIdField = new TextField();
    firstNameField = new TextField();
    lastNameField = new TextField();
    addressField = new TextField();
    provinceField = new TextField();
    postalCodeField = new TextField();
    phoneNumberField = new TextField();
	
	 //Adding fields into border Pane
    pane.add(new Label("Player Information"), 0, 0);
    pane.add(new Label("Player Id:"), 0, 2);
    pane.add(playerIdField, 10, 2);
    pane.add(new Label("First Name:"), 0, 3);
    pane.add(firstNameField, 10, 3);
    pane.add(new Label("Last Name:"), 0, 4);
    pane.add(lastNameField, 10,4);
    pane.add(new Label("Address:"), 0, 5);
    pane.add(addressField, 10, 5); 
    pane.add(new Label("Province:"), 0, 6);
    pane.add(provinceField, 10, 6);
    pane.add(new Label("Postal Code:"), 0, 7);
    pane.add(postalCodeField, 10, 7);
    pane.add(new Label("Phone Number:"), 0, 8);
    pane.add(phoneNumberField, 10, 8);
    return pane;
}

public GridPane addGridPaneRight()
{
	GridPane pane = new GridPane();
	pane.setAlignment(Pos.TOP_RIGHT);
	pane.setPadding(new Insets(15, 15, 15, 15));
	pane.setHgap(10);
    pane.setVgap(10);

    updateplayerid = new TextField();
    gameIdField= new TextField();
    gameTitleField = new TextField();
    scoreField = new TextField();
    datePlayedField= new TextField();
	
	pane.add(new Label("Update Player by ID"), 0, 1);
	pane.add(updateplayerid, 5, 1);
	updatePlayer=new Button("Update");
	pane.add(updatePlayer, 7, 1);
	pane.add(new Label("Game Information"),0, 10);
	pane.add(new Label("Game Id"), 0, 11);
	pane.add(gameIdField, 5, 11);
	pane.add(new Label("Game Title"), 0, 12);
	pane.add(gameTitleField, 5, 12);
	pane.add(new Label("Game Score"), 0, 13);
	pane.add(scoreField,5, 13);
	pane.add(new Label("Date Played"), 0, 14);
	pane.add(datePlayedField, 5, 14);
	return pane;	
}

public GridPane addGridPanebottomRight()
{
	GridPane pane = new GridPane();
	pane.setAlignment(Pos.TOP_RIGHT);
	pane.setPadding(new Insets(15, 15, 15, 15));
	pane.setHgap(10);
    pane.setVgap(10);
	//Create buttons
	createPlayer = new Button("Create Player");
	displayPlayer=new Button("Display All Players");
	pane.add(createPlayer, 0, 1);
	pane.add(displayPlayer, 2, 1);
    return pane;
}


/*

public static void main(String[] args) {
	launch(args);
}

*/
public boolean isDbConnected(Connection con) {
    try {
        return con != null && !con.isClosed();
    } catch (SQLException ignored) {}

    return false;
}







}
